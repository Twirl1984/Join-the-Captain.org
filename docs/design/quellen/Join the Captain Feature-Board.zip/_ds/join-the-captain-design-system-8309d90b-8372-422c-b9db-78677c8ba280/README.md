# Join the Captain — Design System

> Tinder für Segelreisen im Mittelmeer. Wir matchen Crew, Boot und Skipper — für eine Woche, die wirklich passt.

This folder is the design source-of-truth for **Join the Captain** (JTC): a German sailing-crew matching platform. It contains the brand fundamentals (color, type, motion), iconography rules, brand voice notes, and high-fidelity UI kit recreations you can use to build new pages, decks, ad spots, and Instagram content **without re-inventing the look**.

The brand exists today at **[join-the-captain.de](https://join-the-captain.de/join-the-captain.html)** (and the `.com` mirror). Backend / app code lives in the [`Twirl1984/join-the-captain`](https://github.com/Twirl1984/join-the-captain) GitHub repository. Read those for engineering context; read **this** for design context.

---

## What Join the Captain is

A matching marketplace, not a charter agency. Crew fills out a 12-question quiz; a captain matches harmonising crews to weeks on a 10-person yacht; weeks fill up by personality fit, not first-come-first-served. The brand voice promises *honesty over hype*: predictable people, predictable conditions, fewer surprises on 12 m² of saloon for seven days.

**Surfaces represented in this design system:**

| Surface | UI kit | What lives here |
| --- | --- | --- |
| **Website** (`join-the-captain.de`) | `ui_kits/website/` | The matching marketplace itself — hero, trips, week-picker, captain card, FAQ, footer. The visual baseline. |
| **Instagram spots** (Reels + 9:16 story posts) | `ui_kits/instagram/` | The "addictive" video/photo content the user wants to push — full-bleed 9:16 frames re-using brand imagery and captions in JTC voice. |

> **What is *not* yet covered:** the internal skipper dashboard (`dashboard.html`), the quiz UI (`quiz.html`), the email templates. Ask if you need a kit for those.

---

## Source materials referenced

- **GitHub:** [`Twirl1984/join-the-captain`](https://github.com/Twirl1984/join-the-captain) — full product codebase (HTML, CSS, Node API).
- **Live site:** [`join-the-captain.de/join-the-captain.html`](https://join-the-captain.de/join-the-captain.html).
- **Brand voice spec:** [`reference/SKILL_sprache.md`](reference/SKILL_sprache.md) — internal voice guide. Copy-pasted into this repo for reference; the rules below are distilled from it.
- **Marketing pitch:** [`reference/konzept-pitch.md`](reference/konzept-pitch.md) — short and long pitch, IG story script.
- **Imported CSS:** [`assets/css/`](assets/css/) — the live product's `base.css`, `components.css`, `pages/home.css`. Treat these as ground truth when in doubt.

If you have access to the GitHub repo above, explore further — there are full email templates, the matching algorithm, and additional landing pages (`angebote.html`, `freunde.html`, `feedback.html`, `mein-bereich.html`) that show edge-case patterns.

---

## Index — what's in this folder

```
README.md                          ← you are here
SKILL.md                           ← Claude Code / Agent-Skill manifest
colors_and_type.css                ← all design tokens (CSS variables) + base type
image-slot.js                      ← <image-slot> web component for user photo drops
fonts/README.md                    ← font sourcing notes
assets/
  ├── css/                         ← live product CSS (base, components, pages)
  ├── images/skipper/              ← captain-chris.jpg (the only real photo asset)
  ├── icons/                       ← maritime SVG icon set (curated)
  └── logos/                       ← wordmark variants
preview/                           ← Design System tab cards (Type / Color / Spacing / Components / Brand)
ui_kits/
  ├── website/                     ← React-ish JSX recreations of the join-the-captain.de surfaces
  │     index.html, NavBar.jsx, Hero.jsx, MatchFlow.jsx, TripCard.jsx,
  │     WeekPicker.jsx, CaptainCard.jsx, Footer.jsx, Buttons.jsx, …
  └── instagram/                   ← 9:16 story-post & reel templates
        index.html, StoryHero.jsx, StoryPain.jsx, StorySolution.jsx, …
reference/
  ├── original-README.md           ← upstream README from the JTC repo
  ├── SKILL_sprache.md             ← the brand voice spec (authoritative)
  ├── konzept-pitch.md             ← marketing concept document
  └── join-the-captain.html        ← the live landing page, frozen copy
```

---

## CONTENT FUNDAMENTALS — how JTC speaks

The voice is **honest, direct, German-first, low-cliché**. The full source rules live in [`reference/SKILL_sprache.md`](reference/SKILL_sprache.md); here are the load-bearing ones.

### Voice in three sentences

1. **Ehrlich-direkt.** Say what's true — including the uncomfortable parts (the 50 % deposit becomes binding when the skipper books the boat). No tricks, no upsell theatre.
2. **Maritim ohne Klischee.** Use sailing terms where they actually belong (*Törn, Crew, Skipper, Bordkasse*) — but never *"Ahoi"*, never *"klar Schiff"*, never *"Anker lichten"*. The world sounds like the sea, not like a pirate movie.
3. **Locker, aber präzise.** Du-anrede. Short main clauses, often with a period instead of a comma. Exact numbers, clear conditions, no *"We are excited to announce"*.

### Hard rules

- **Always "du", never "Sie"** — even in legal text where possible.
- **Imperative without the *-e* ending:** "Klick rein", "Wähl deine Wochen", "Schau dir an". *Not* "Klicke" / "Wähle" / "Schaue".
- **En-dash (–) not hyphen (-)** for ranges and asides: *"7 Tage – Sa–Fr"*, *"Mai – Oktober"*.
- **Non-breaking space between number and unit:** *"990 €"*, *"50 %"*, *"7 Tage"* (HTML `&nbsp;`).
- **Bullets in running text use the middle-dot (·):** *"Palma · Ibiza · Formentera"*. No commas for station lists.
- **German curly quotes**: „typografisch", not "gerade".
- **Prices: € *after* the number**: *"990 €"*, never *"€ 990"* or *"990€"*.
- **Max one exclamation mark per paragraph. Max one emoji per section, and only functional** (📅 in front of a date, 🔒 in front of a security note, ⛵ as a boat-type marker). Never as decoration.

### Banned phrases

- *"Ahoi"* (one nostalgic footer exception aside).
- *"Klar Schiff" · "Anker lichten" · "Mann über Bord" · "auf Kurs" · "ins Trockendock"* as metaphors.
- *"Wir freuen uns" · "Es ist uns eine Ehre" · "Herzlichen Dank für Ihr Interesse"*.
- *"Revolutionär" · "einzigartig" · "weltweit führend" · "die Nr. 1"*.
- *"Hier klicken"* as a CTA. CTAs name the **action**: *"Quiz starten →"*, *"Platz reservieren →"*.

### Glossary (use these terms, not the alternatives)

| Use | Don't use |
| --- | --- |
| **Crew** | Mitsegler · Passagiere · Gruppe |
| **Skipper** (technical) / **Captain** (warm) | Kapitän · Steuermann |
| **Törn** | Trip · Tour · Cruise · Reise |
| **Match** / **matchen** | Vermittlung · Zuordnung |
| **Bordkasse** | Verpflegungspauschale · Kasse |
| **Quiz** | Fragebogen · Persönlichkeitstest |
| **Koje** / **Kabine** | Bett · Zimmer · Kammer |
| **Anzahlung** | Deposit · Vorauszahlung |

### Tone by context

| Context | Tone | Example |
| --- | --- | --- |
| **Hero / H1** | Strong, two short halves, italics on the noun. | *"Finde deine Crew. Erlebe **das Meer**."* |
| **Konzept-Erklärung** | Sachlich-aufklärend, "we flip it around", "bedeutet:" | *"Wir matchen dich mit der passenden Crew … Bewerbung ist kostenlos."* |
| **FAQ-Antwort** | Honest-precise, answers the question even if uncomfortable. | *"Nein. Wer mit anpacken will, darf — wer entspannen will, tut das."* |
| **Wochenbeschreibung** | Atmospheric, sensory, fragments. | *"Aufstehen wer mag. Sprung ins Wasser. Kaffee."* |
| **Erfolgsmeldung** | Knapp, no *"Glückwunsch"*. | *"Reservierung eingegangen. Wir starten jetzt das Matching."* |
| **Instagram** | Looser, same vibe, max 5 hashtags. | *"Slow Mornings. Sailing Afternoons. Long Evenings. ⛵"* |

### Sentence patterns that work

- **Antithesis** — *"Klassische Anbieter verkaufen feste Termine. Wir drehen das um."*
- **Triade with periods** — *"Aufstehen wer mag. Sprung ins Wasser. Kaffee."*
- **"Bedeutet:" pattern** — *"Bedeutet: Findet sich keine Crew, bekommst du alles zurück."*
- **Short pointed ending** — *"Du machst Urlaub. Punkt."*
- **Sparse English keywords** — *"Slow Mornings, Sailing Afternoons, Long Evenings"* as a header, never inside a paragraph.

---

## VISUAL FOUNDATIONS — how JTC looks

### Mood

Late golden hour on the Mediterranean from inside the cockpit. Dark sea-blue ground, salt-cream type, brass-gold accent that does all the highlighting. **Photography-led, not illustration-led.** Sharp corners, hairline borders, generous whitespace. The brand reads more like a small-batch hotel magazine than a tech startup.

### Color

JTC has **one canvas (deep navy), one paper (salt cream), one accent (gold)**, plus a teal accent for surfaces and an ember for warnings/contrast.

| Token | Hex | Where it shows up |
| --- | --- | --- |
| `--jtc-deep` | `#08131e` | Default page background. The colour of the sea at night. |
| `--jtc-navy` | `#112233` | Alternating section background; modal / card surfaces. |
| `--jtc-ink` | `#0d1b2a` | Foreground text on a gold button; the darkest punch. |
| `--jtc-salt` | `#f2ede4` | All foreground text on the dark canvas — never pure white. |
| `--jtc-sand` | `#e5ddd0` | Slightly warmer paper variant, used sparingly. |
| `--jtc-gold` | `#c8a84b` | The brand accent. Italics, eyebrow labels, CTAs, the captain's frame. |
| `--jtc-teal` / `--jtc-teal2` | `#1a5f7a` / `#23809e` | Available-week tint, accent button outline, secondary highlight. |
| `--jtc-ember` | `#c05a2b` | Urgency, "almost full", the secondary contact CTA. |
| `--jtc-mist` | `rgba(242,237,228,0.07)` | Surface tint on dark — barely-there panels. |
| `--jtc-line` | `rgba(242,237,228,0.12)` | The hairline border used absolutely everywhere. |

**Rules of thumb.** Backgrounds rotate `--jtc-deep` ↔ `--jtc-navy` between sections — never gradients between sections. Gold is a *highlighting* color, not a fill — it lands on italic words, eyebrow labels, primary CTAs, and 1-pixel frames. Ember is the only "loud" color and should appear at most once per screen. Never use pure white (`#fff`) for type; always `--jtc-salt` so it doesn't vibrate against the deep navy.

### Type

**Two families. That's the system.**

- **Playfair Display** (serif) — display, section titles, card titles, pull-quotes, prices. Weights 400 + italic 400. Italic on the *accent word* is the brand signature: *"Wähle **dein Abenteuer**"*, *"Transparent & **fair**"*.
- **Outfit** (sans) — body, UI, navigation, buttons, fields, captions. Weights 300 (default body) / 400 / 500 (button labels, light emphasis).

Eyebrows are tiny: **0.65rem · `letter-spacing: 0.38em` · uppercase · gold.** Buttons are slightly less spaced: **0.8rem · `letter-spacing: 0.18em` · uppercase**. Body copy is set at 300 weight at ~0.92rem with `opacity: 0.68–0.78` and `line-height: 1.85` — JTC paragraphs feel airy, never dense.

### Spacing & rhythm

Sections are huge: **`padding: 6rem 2rem`** is the default vertical rhythm. Inside a section, the content max-width is **1180px**, centered. Grids use **2-pixel gaps**, not generous gaps — adjacent panels feel almost like one piece of brushed material with a hairline seam.

### Borders, corners, shadows

- **Corners are sharp.** `border-radius: 0` is the default for cards, panels, buttons, fields, modals. The few rounded elements: status dots (`50%`), avatars (`50%`), progress fills (`999px`), badges (`2px`), and one dashboard onboarding card (`8px`).
- **Borders are always 1px.** The line color is `rgba(242,237,228,0.12)`. There is no 2px / 3px border in the system except for the gold left-border on pull-quotes.
- **Shadows barely exist.** The only ambient shadow in the live product is `0 0 32px rgba(200,168,75,0.15)` — the gold glow ring on the captain's portrait. Cards lift on hover via *background tint* (`--jtc-mist` darkens), not via shadow.

### Backgrounds

Full-bleed photography is the hero pattern: a Mediterranean shot with a radial teal vignette and a soft top-to-bottom dark fade. No repeating textures, no patterns, no SVG illustrations. When photography isn't available, use a solid `--jtc-navy` block — a flat color is more on-brand than a gradient or a stock illustration.

### Imagery vibe

Warm, sun-bleached, slightly desaturated. The captain photo runs `filter: grayscale(.15) contrast(1.05)` to pull the saturation down. Gallery thumbs default to `brightness(.82) saturate(.9)` and bloom on hover. Imagery should feel like a 35mm photo at golden hour — never the over-saturated drone shots typical of charter marketing.

### Animation

Two patterns, that's it.

- **`fadeUp`** on intersection (`opacity 0 → 1`, `translateY(24px) → 0`, 0.7s ease).
- **Slow photo zoom** on hover for trip cards (`transform: scale(1.07)`, 0.8s cubic-bezier(.25,.46,.45,.94)`).

No bounces. No springs. No parallax. Hover states on buttons are a 2px lift + background tint change in 0.3s. The brand is calm; the motion vocabulary is calm.

### Hover & press

- **Gold primary** (`.btn-gold`) → background brightens to `#dbb84d`, `translateY(-2px)`. No darkening.
- **Ghost button** (`.btn-ghost`) → border colour shifts to gold, text colour shifts to gold. No fill.
- **Nav link** → opacity `0.7 → 1`, color shifts to gold.
- **Trip card** → background image zooms in 7 %, crew-preview row reveals (`max-height: 0 → 50px`).
- **Form field focus** → border color → gold. No outer ring.
- There is **no press / active state** in the live CSS — taps just lead. Mobile feels responsive enough thanks to the immediate hover-state colors.

### Transparency & blur

Used sparingly. The nav bar gets `backdrop-filter: blur(4px)` over a 97 % opaque dark gradient. The modal overlay gets `backdrop-filter: blur(8px)`. Tinted overlays on photography use 30–60 % dark fades, never coloured tints over images.

### Layout rules

- **Sticky nav** (96 %+ opaque) — `padding: 1.2rem 3rem`, hairline bottom border.
- Section padding: **`6rem 2rem`** desktop, **`4rem 1.2rem`** mobile.
- Section body max-width: **1180px**.
- Grids: 2 px gaps, not 16 / 24 / 32. JTC reads as a *grid of plates*, not a card list.
- 3-column responsive collapse: 4 → 3 → 2 → 1 at `1100 / 960 / 600`.

### Component DNA

- **Cards** never have shadows; they have hairline borders and a `--jtc-mist` tinted surface. Hover lifts the tint, not the elevation.
- **Buttons** are flat rectangles. Gold primary (uppercase, letter-spaced), ghost outline (uppercase, letter-spaced), small ghost (`.btn-sm`) for table actions. No fully-rounded pill buttons except the gold nav-pill which is `border-radius: 0` and only *visually* a pill by virtue of being short and gold.
- **Badges** are 2-px-rounded, ALL CAPS, 0.62rem, `letter-spacing: 0.15em`. Tinted on a 15 % colour-wash with a 30 % colour border.
- **Form fields** are flat rectangles: `rgba(242,237,228,.05)` fill, hairline border, `border-radius: 0`. Focus turns the border gold.
- **Accordions** use a gold `+` icon that rotates 45° on open. No chevrons.

---

## ICONOGRAPHY

JTC's iconography is **minimal by design**. The live product uses **functional emoji** (⚓ ⛵ 👤 🔒 🔍 📅 🏊 🎒 🚫) sprinkled into navigation labels, accordion question heads, and step icons — and a handful of inline SVGs for social-network logos (Instagram, Facebook) only. There is no icon font, no Lucide / Heroicons import, no curated SVG sprite sheet.

**The rule:** *emoji is reserved for functional roles* — a marker before a date, a category prefix on an accordion question, a step icon in a 4-card explainer. Never decorative. Max one emoji per visual unit.

### What lives in `assets/icons/`

- **`social-instagram.svg`**, **`social-facebook.svg`** — the only real SVG icons in the live product. Used in nav and footer at 16–17 px.
- **A small curated SVG set** added in this design system (rudder, sailboat, anchor, wind, sun, calendar, lock, search, chevron, plus, close) at uniform 1.5 px stroke for cases where you want a more refined replacement for the emoji. **These are substitutions, flagged below.**

### Approved emoji vocabulary

| Emoji | Use for | Where it appears live |
| --- | --- | --- |
| ⚓ | Boat-type/anchor marker, hero badge | hero badge, accordion |
| ⛵ | Sailboat / Instagram captions | IG copy, footer pun |
| 👤 | Person / skipper / role | accordion question |
| 💰 | Cost / Bordkasse | accordion question |
| 🏊 | Swimming requirement | accordion question |
| 🎒 | Packing list | accordion question |
| 🚫 | Drugs/alcohol policy | accordion question |
| 📅 | Date / week | reservation modal |
| 🔒 | Security / SSL | reservation submit |
| 🔍 | Search / filter | dashboard |

**Avoid:** 🚀 ✨ ⭐ 💯 🎉 — none of these fit the maritime-not-piratical tone.

### Substitutions flagged

This design system ships a small curated SVG icon set at `assets/icons/`. **These are designer substitutions, not from the upstream repo.** They follow the JTC stroke style (1.5 px, no fill, salt color, with gold accent variant) but should be reviewed before going into production. If you want production-quality SVGs, ask the user to source or commission them, or substitute the closest CDN match (e.g. Lucide `anchor`, `sailboat`, `wind`, `compass` — all 1.5 px stroke matches the JTC weight).

---

## ⚠️ Substitutions & open questions

These are not from the upstream — flag with the user before shipping:

1. **Fonts.** `Playfair Display` and `Outfit` are loaded from Google Fonts directly (the live product does the same). No `.woff2` files are included. If you need self-hosted fonts, ask for licensed files.
2. **Photography.** Only one real photo asset exists in the repo (`captain-chris.jpg`). All hero, trip, gallery, and Instagram-template imagery currently uses Unsplash placeholders or `<image-slot>` web components so the user can drag in their own iCloud / Google Photos sailing pictures. **The user has stated they have a large image library — this design system is wired to drop them in.**
3. **Icons.** The curated SVG set under `assets/icons/` was added by this design system as a substitute for the live product's emoji-only approach. If you ship to production, either keep using emoji (the brand-correct choice) or have the SVG set design-reviewed.
4. **No `dashboard` / `quiz` UI kits** are included. They exist in code (`dashboard.html`, `quiz.html`) — ask if you need recreations.

---

## How to use this design system

- **Building a new website page?** Open `ui_kits/website/index.html`, copy the JSX components you need, import `colors_and_type.css` and `assets/css/components.css`. The components are intentionally cosmetic — they look right but don't include real form submission.
- **Building Instagram content?** Open `ui_kits/instagram/index.html`. Each 9:16 slide is a `<section>` you can screenshot at 1080×1920 or 1080×1350. Drop user-supplied photos into the `<image-slot>` placeholders.
- **Need just a color or font?** Import `colors_and_type.css` — every token is a `--jtc-*` CSS variable.
- **Writing copy?** Read [`reference/SKILL_sprache.md`](reference/SKILL_sprache.md) in full before you write anything user-facing.
